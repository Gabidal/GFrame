package fi.quanfoxes;

import android.app.*;
import android.os.*;
import android.util.*;
import android.widget.*;
import android.content.*;
import java.net.*;
import java.nio.*;
import java.io.*;
import java.util.*;
import android.text.*;

public class MainActivity extends Activity 
{
	public EditText edit;
	public EditText Intrepeter;
	public String fileTeller = "";
	public static Vector<String> buffer;
	public String notice = "";
	public TextView b;
	public TextView history;
	public Lexer lexer;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		final fetcher a = new fetcher();
		edit = (EditText)findViewById(R.id.input);
		Intrepeter = (EditText)findViewById(R.id.Interpreter);
		b = ((TextView) findViewById(R.id.output));
		history = ((TextView) findViewById(R.id.history));
		Thread t = new Thread(new Runnable(){
				@Override public void run()
				{

					SharedPreferences reader = getSharedPreferences("save", MODE_PRIVATE);
					double x = reader.getFloat("ID", 0);
					notice += "Youre current verstion\n: " + String.valueOf(x) + "\n";

					double y = a.getJson(".g");
					notice += "Latest release\n: " + String.valueOf(y) + "\n";
					if (y - x > 0.001)
					{
						SharedPreferences.Editor editor = reader.edit();
						editor.putFloat("ID", (float)y);
						editor.apply();
						notice += "Updating...\n";
						a.download("storage/emulated/0/");
						notice += "Youre GCore is up to date :D\n";

					}
					else
					{
						notice += "No need to update.\n";
					}

					update();
				}
			});
		t.start();

	}
	public void update()
	{
		runOnUiThread(new Runnable(){
				@Override public void run()
				{
					b.setText(notice);
					edit.addTextChangedListener(new TextWatcher(){
							public void afterTextChanged(Editable s)
							{   //Convert the Text to String
								String inputText = edit.getText().toString();
								
								if (read(inputText) == false){
									history.setText( history.getText() + "\n" + inputText);
									edit.setText("");
								}
								if (read(Intrepeter.getText().toString()) == false)
								{
									lexer  = new Lexer(Intrepeter.getText().toString());
								}
								String result = format(notice, "\n", fileTeller);
								b.setText(result);
							}
							public void beforeTextChanged(CharSequence s, int start, int count, int after)
							{
								// TODO Auto-generated method stub
							}
							public void onTextChanged(CharSequence s, int start, int before, int count)
							{
							}
						});
				}
			});
	}

	public String format(String a, String b, String c)
	{
		return (a + b + c);
	}

	public Boolean read(String input)
	{
		String fileName = input;
		if (fileName.contains("\n") != true)
		{
			return true;
		}
		else
		{
			fileTeller = "Searching for given file\n";
			fileName = fileName.substring(0, fileName.length() - 1);
		}
		fileName = "/storage/emulated/0/" + fileName;
		BufferedReader br = null;
		try
		{
			try
			{
				File file = new File(fileName);

				if (file.exists())
				{
					fileTeller = "file was found!\n";
				}
				else
				{
					fileTeller = "file not found!\n";
				}
				br = new BufferedReader(new FileReader(file));
				String line;
				while ((line = br.readLine()) != null)
				{
					buffer.add(line);
					lexer = new Lexer(line);
				}
			}
			finally
			{
				br.close();
			}
		}
		catch (Exception u)
		{	
		}
		return false;
	}
}
