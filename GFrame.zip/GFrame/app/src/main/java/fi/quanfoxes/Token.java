package fi.quanfoxes;
import java.util.*;

public class Token
{
	private String name = "nulnulEmpty";
	private String Owner = "";
	private String addedName = "";
	private int ParameterAmount = 0;
	private Vector<String> InheritadedFunctions;
	private String PointingOn = "";
	private int IValue = 0;
	private String SValue = "";
	private Register Register;
	private String Math = "";
	private String Code = "";
	
	public boolean ifkilled;
	public boolean ifLocal;
	public boolean ifFunction;
	public boolean ifType;
	public boolean ifVar;
	public boolean ifString;
	public boolean ifIf;
	public boolean ifElse;
	public boolean ifEnd;
	public boolean ifReturnable;
	public boolean ifPointter;
	public boolean IfHasRegister;
	public boolean ifMath;
	public boolean ifIncluding;
	public boolean ifExternal;
	public boolean ifIndirect;
	
	public String getFullName()
	{
		String result;
		result = addedName + name;
		return result;
	}
	public String getFromMem()
	{
		return ("[" + addedName + name + "]");
	}
	private Register makeNewReg()
	{
		int x = RegInfo.RegisterCounter;
		if (x >= 15)
		{
			RegInfo.RegisterCounter = 0;
		}
		return Lexer.GeneralRegisters.get(x);
	}
	public String getRegName()
	{
		if (IfHasRegister && Register != null)
		{
			return Register.Name;
		}
		else
		{
			return makeNewReg().Name;
		}
	}
	public int getRegVal()
	{
		if (IfHasRegister && Register != null)
		{
			return Register.value;
		}
		else
		{
			return makeNewReg().value;
		}
	}
	public boolean isRegPtr()
	{
		if (IfHasRegister && Register != null)
		{
			return Register.ifPointter;
		}
		else
		{
			return makeNewReg().ifPointter;
		}
	}
}
