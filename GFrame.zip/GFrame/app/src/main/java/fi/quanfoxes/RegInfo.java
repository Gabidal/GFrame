package fi.quanfoxes;

public class RegInfo
{
	RegInfo(){
		Lexer.GeneralRegisters.add(RegInfo.R0);
		Lexer.GeneralRegisters.add(RegInfo.R1);
		Lexer.GeneralRegisters.add(RegInfo.R2);
		Lexer.GeneralRegisters.add(RegInfo.R3);
		Lexer.GeneralRegisters.add(RegInfo.R4);
		Lexer.GeneralRegisters.add(RegInfo.R5);
		Lexer.GeneralRegisters.add(RegInfo.R6);
		Lexer.SpecialRegisters.add(RegInfo.R7);
		Lexer.GeneralRegisters.add(RegInfo.R8);
		Lexer.GeneralRegisters.add(RegInfo.R9);
		Lexer.GeneralRegisters.add(RegInfo.R10);
		Lexer.SpecialRegisters.add(RegInfo.R11);
		Lexer.SpecialRegisters.add(RegInfo.R12);
		Lexer.SpecialRegisters.add(RegInfo.R13);
		Lexer.SpecialRegisters.add(RegInfo.R14);
		Lexer.SpecialRegisters.add(RegInfo.R15);
	}
	
	
	static public int RegisterCounter = 0;
	static Register R0 = new Register("r0", true);
	static Register R1 = new Register("r1", true);

	static Register R2 = new Register("r2", true);
	static Register R3 = new Register("r3", true);

	static Register R4 = new Register("r4", true);
	static Register R5 = new Register("r5", true);

	static Register R6 = new Register("r6", true);
	static Register R7 = new Register("r7", false);

	static Register R8 = new Register("r8", true);
	static Register R9 = new Register("r9", true);

	static Register R10 = new Register("r10", true);
	static Register R11 = new Register("r11", false);

	static Register R12 = new Register("r12", false);
	static Register R13 = new Register("r13", false);

	static Register R14 = new Register("r14", false);
	static Register R15 = new Register("r15", false);
	
	
}
