package fi.quanfoxes;

public class Register
{
	public int value;
	public String Name;
	public int Priority;
	
	public Register(String name, boolean ifgeneral)
	{
		Name = name;
		ifGeneral = ifgeneral;
		Priority = 0;
		value = 0;
	}
	
	public boolean ifPointter = false;
	public boolean ifGeneral = false;
	public boolean ifStackBase = false;
	public boolean ifStackTop = false;
}
