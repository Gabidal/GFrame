package fi.quanfoxes;
import java.util.*;

public class Lexer
{
	public Lexer(String line)
	{
		Line = line;
		analize(Line);
	}
	public String Line;
	public String Buffer;
	Vector<Token> Tokens;
	static Vector<Register> GeneralRegisters;
	static Vector<Register> SpecialRegisters;
	public int Layer = 0;
	public int ID = 0;

	public String getWord(char wanted, String Source, int index)
	{
		String destination = "";
		while (Source.charAt(index) !=  wanted || Source.charAt(index) != '\n' || index <= Source.length())
		{
			destination += Source.charAt(index);
			index++;
		}
		return destination;
	}
	
	public char getError(char end, String source, int continu)
	{
		String destination = "";
		char ended;
		for (int i = continu; i < source.length();i++)
		{
			if (source.charAt(i) != end && source.charAt(i) != '\n')
			{
				destination += source.charAt(i);
			}
			else
			{
				ended = source.charAt(i);
				i++;
				return ended;
			}

		}

		return '\n';
	}

	public Vector<Token> getParameters(String in)
	{
		int offset = 0;
		int index = 0;
		while (true)
		{
			String para2;
			char error;
			error = getError(',', in, index);
			para2 = getWord(',', in, index);
			offset = para2.length();
			if (para2.length() < 1 || para2.indexOf(')') != -1)
			{
				para2 = "";
				error = getError(')', para2, index);
				para2 = getWord(')', in, index);
				offset = para2.length();
				if (para2 == "")
				{
					//if no parameters
					index = offset;
					break;
				}
			}
			else
			{
				offset++; // skip the " " after the ,
			}
			Token Parameter = new Token();
			Parameter.makeName(para2);
			if (error == '\n')
			{
				if (para2 != "(")
				{
					index = offset;
				}
				break;
			}
			else if (error == ')')
			{
				index = offset;
				break;
			}
			else
			{
				index = offset;
			}
			Tokens.add(Parameter);
		}
		return Tokens;
	}
	
	public void prepareFunc(){
		
	}
	
	public void makeInitialDestination(){
		
	}
	
	public void getInitialDestination(){
		
	}
	
	public void doMath(){
		
	}

	private void analize(String line)
	{

	}
}
