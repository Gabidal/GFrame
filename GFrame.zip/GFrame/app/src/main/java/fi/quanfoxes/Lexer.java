package fi.quanfoxes;
import java.util.*;

public class Lexer
{
	public Lexer()
	{
		GeneralRegisters.add(RegInfo.R0);
		GeneralRegisters.add(RegInfo.R1);
		GeneralRegisters.add(RegInfo.R2);
		GeneralRegisters.add(RegInfo.R3);
		GeneralRegisters.add(RegInfo.R4);
		GeneralRegisters.add(RegInfo.R5);
		GeneralRegisters.add(RegInfo.R6);
		SpecialRegisters.add(RegInfo.R7);
		GeneralRegisters.add(RegInfo.R8);
		GeneralRegisters.add(RegInfo.R9);
		GeneralRegisters.add(RegInfo.R10);
		SpecialRegisters.add(RegInfo.R11);
		SpecialRegisters.add(RegInfo.R12);
		SpecialRegisters.add(RegInfo.R13);
		SpecialRegisters.add(RegInfo.R14);
		SpecialRegisters.add(RegInfo.R15);
	}
	Vector<Token> Tokens;
	static Vector<Register> GeneralRegisters;
	static Vector<Register> SpecialRegisters;
}
