package fi.quanfoxes.ndk;
import java.util.*;
import android.util.*;

public class Token
{
	private String name = "nulnulEmpty";
	private String Owner = "";
	private String addedName = "";
	private int ParameterAmount = 0;
	private Vector<String> InheritadedFunctions;
	private String PointingOn = "";

	private int IValue = 0;
	private String SValue = "";
	private Register Register;	private String Math = "";
	private String Code = "";
	private Vector<Token> Parameters;
	private int ID;
	private int Layer;
	private int size;
	private String file;
	
	public boolean ifkilled;
	public boolean ifLocal;
	public boolean ifFunction;
	public boolean ifType;
	public boolean ifVar;
	public boolean ifString;
	public boolean ifArray;
	public boolean ifIf;
	public boolean ifElse;
	public boolean ifEnd;
	public boolean ifReturnable;
	public boolean ifPointter;
	public boolean IfHasRegister;
	public boolean ifMath;
	public boolean ifIncluding;
	public boolean ifExternal;
	public boolean ifIndirect;
	public boolean ifStart;
	
	public String getFullName(){
		String result;
		result = addedName + name;
		return result;
	}
	public String getFromMem(){
		return ("[" + addedName + name + "]");
	}
	private Register makeNewReg(){
		int x = RegInfo.RegisterCounter;
		if (x >= 15)
		{
			RegInfo.RegisterCounter = 0;
		}
		return Lexer.GeneralRegisters.get(x);
	}
	public String getRegName(){
		if (IfHasRegister && Register != null)
		{
			return Register.Name;
		}
		else
		{
			return makeNewReg().Name;
		}
	}
	public int getRegVal(){
		if (IfHasRegister && Register != null)
		{
			return Register.value;
		}
		else
		{
			return makeNewReg().value;
		}
	}
	public boolean isRegPtr(){
		if (IfHasRegister && Register != null)
		{
			return Register.ifPointter;
		}
		else
		{
			return makeNewReg().ifPointter;
		}
	}
	public void makeName(String n){
		name = n;
	}
	public void makeVar(String value){
		SValue = value;
		IValue = Integer.parseInt(SValue);
	}
	public void makeArray(String s){
		ifArray = true;
		size = Integer.parseInt(s);
	}
	public void makePublic(){
		ifLocal = false;
	}
	public void makeLocal(String TypeName, String FuncName){
		ifLocal = true;
		addedName = TypeName + "." + FuncName + ".";
	}
	public void makeFunc(){
		ifFunction = true;
	}
	public void makeType(){
		ifType = true;
	}
	public void delete(){
		ifkilled = true;
	}
	public void makeString(){
		ifString = true;
	}
	public void makeIf(Token a, Token condition, Token b, int Id, int layer){
		ifIf = true;
		Parameters.add(a);
		Parameters.add(condition);
		Parameters.add(b);
		ID = Id;
		Layer = layer;
	}
	public void makeElse(int Id, int layer){
		ifElse = true;
		ID = Id;
		Layer = layer;
	}
	public int makeEnd(int layer){
		if (layer == 1){
			ifEnd = true;
			layer--;
			Layer = layer;
			return layer;
		}else{
			layer--;
			Layer = layer;
			return layer;
		}
	}
	public int makeStartStackFrame(int layer){
		layer++;
		Layer = layer;
		ifStart = true;
		return layer;
	}
	public void makeReturnable(){
		ifReturnable = true;
	}
	public void makePointer(){
		ifPointter = true;
	}
	public void makeMath(String math){
		Math = math;
		ifMath = true;
	}
	public void makeInclude(String fileName){
		ifIncluding = true;
		file = fileName;
	}
	public void makeExtern(){
		ifExternal = true;
	}
	public void makeIndirect(){
		ifIndirect = true;
	}
}
