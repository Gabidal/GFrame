package fi.quanfoxes.ndk;


import android.app.*;
import android.os.*;
import android.util.*;
import android.widget.*;
import android.content.*;
import java.net.*;
import java.nio.*;
import java.io.*;
import java.util.*;
import android.text.*;
import java.lang.*;
import org.apache.http.*;

public class MainActivity extends Activity 
{
	public EditText edit;
	public EditText Intrepeter;
	public String fileTeller = "";
	public static Vector<String> buffer;
	public String notice = "";
	public TextView b;
	public TextView history;
	public Lexer lexer = new Lexer("");;
	public boolean ifApply = false;
	public boolean ifRun = false;
    @Override
	static
	{
		System.loadLibrary("Func");
	}
	public static native void modifyGC(String name, String justName);
	public static native void runGC(String name);
    protected void onCreate(Bundle savedInstanceState)
    {
		
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		final fetcher a = new fetcher();
		edit = (EditText)findViewById(R.id.input);
		Intrepeter = (EditText)findViewById(R.id.Interpreter);
		b = ((TextView) findViewById(R.id.output));
		history = ((TextView) findViewById(R.id.history));
		Thread t = new Thread(new Runnable(){
				@Override public void run()
				{

					SharedPreferences reader = getSharedPreferences("save", MODE_PRIVATE);
					double x = reader.getFloat("ID", 0);
					notice += "Youre current version\n: " + String.valueOf(x) + "\n";

					double y = a.getJson("x86");
					notice += "Latest release\n: " + String.valueOf(y) + "\n";
					if (y - x > 0.001)
					{
						SharedPreferences.Editor editor = reader.edit();
						editor.putFloat("ID", (float)y);
						editor.apply();
						notice += "Updating...\n";
						a.download("storage/emulated/0/");
						notice += "Youre GCore is up to date :D\n";

					}
					else
					{
						notice += "No need to update.\n";
					}

					update();
				}
			});
		t.start();

	}
	public void update()
	{
		runOnUiThread(new Runnable(){
				@Override public void run()
				{
					b.setText(notice);
					edit.addTextChangedListener(new TextWatcher(){
							public void afterTextChanged(Editable s)
							{   //Convert the Text to String
								String inputText = edit.getText().toString();

								
								
								if (inputText.contains("G:apply") && inputText.contains("\n"))
								{
									String skip = lexer.getWord(' ', inputText, 0);
									String fileName = lexer.getWord('\n', inputText, skip.length() + 1);
									File f = new File(fileName);
									modifyGC(fileName, f.getName());
									fileTeller = "Youre file was made executable\n";
								}
								else if (inputText.contains("G:run") && inputText.contains("\n"))
								{
									String skip = lexer.getWord(' ', inputText, 0);
									String fileName = lexer.getWord('\n', inputText, skip.length() + 1);
									runGC(fileName);
									fileTeller = "Running youre executable";
								}
								else if (inputText.contains("help")){
									fileTeller = "Type:\n G:apply [folder/file name]\nTo make youre binary file an executable file\n\n G:run [applyed file]\n";
									String result = format(notice, "\n", fileTeller);
									b.setText(result);
								}
								if (read(inputText) == false){
									history.setText( history.getText() + "\n" + inputText);
									edit.setText("");
								}
								String result = format(notice, "\n", fileTeller);
								b.setText(result);
							}
							public void beforeTextChanged(CharSequence s, int start, int count, int after)
							{
								// TODO Auto-generated method stub
							}
							public void onTextChanged(CharSequence s, int start, int before, int count)
							{
							}
						});
				}
			});
	}

	public String format(String a, String b, String c)
	{
		return (a + b + c);
	}

	public Boolean read(String input)
	{
		String fileName = input;
		if (fileName.contains("\n") != true)
		{
			return true;
		}
		else
		{
			fileTeller = "Searching for given file\n";
			fileName = fileName.substring(0, fileName.length() - 1);
		}
		fileName = "/storage/emulated/0/" + fileName;
		BufferedReader br = null;
		try
		{
			try
			{
				File file = new File(fileName);

				if (file.exists())
				{
					fileTeller = "file was found!\n";
				}
				else
				{
					fileTeller = "file not found!\n";
				}
				br = new BufferedReader(new FileReader(file));
				String line;
				while ((line = br.readLine()) != null)
				{
					buffer.add(line);
					lexer = new Lexer(line);
				}
			}
			finally
			{
				br.close();
			}
		}
		catch (Exception u)
		{	
		}
		return false;
	}
}

