package fi.quanfoxes.ndk;

public class Terminal
{
	public boolean ifGStroke = false;
	private String cmd;
	public void input(String in)
	{
		cmd = in;
	}
	void check()
	{
		if (cmd.contains("G::start"))
		{
			ifGStroke = true;
		}
		else if (cmd.contains("G::exit"))
		{
			ifGStroke = false;
		}
		if (ifGStroke)
		{
			
		}
	}
}
