	#include <iostream>
	#include <cstdlib>
	#include <jni.h>
	#include <string>
	using namespace std;
	
	extern "C"
	{
		
		
		void Java_fi_quanfoxes_ndk_MainActivity_modifyGC(JNIEnv* env, jobject caller, jstring name, jstring justName)
		{
			jboolean isCopy;
			const char *Name = (env)->GetStringUTFChars(name, &isCopy);
			const char *Nameb = (env)->GetStringUTFChars(justName, &isCopy);
			string a(Name);
			string c(Nameb);
			//system(("echo " + a + " > /storage/emulated/0/GAS/test.g").c_str());
			system(("su -c \"mv /storage/emulated/0/" + a + " /sbin\"").c_str());
			
			system(("su -c \"chmod 777 /sbin/" + c +"\"").c_str());

		}

		void Java_fi_quanfoxes_ndk_MainActivity_runGC(JNIEnv* env, jobject caller, jstring name)
		{
			jboolean isCopy;
            const char *Name = (env)->GetStringUTFChars(name, &isCopy);
            string a(Name);
            system(("su -c " + a).c_str());
		}
		
		
	}
